G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,9.0.7*
G04 #@! TF.CreationDate,2026-09-28T21:56:36-05:00*
G04 #@! TF.ProjectId,MCL-DSP8x8_OUTPUT_RCA,4d434c2d-4453-4503-9878-385f4f555450,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.7) date 2026-09-28 21:56:36*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10R,1.700000X1.700000*%
%ADD11C,1.700000*%
%ADD12C,2.500000*%
%ADD13RoundRect,0.250000X0.350000X0.450000X-0.350000X0.450000X-0.350000X-0.450000X0.350000X-0.450000X0*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,J1*
X54920000Y-52000000D03*
D11*
X57460000Y-52000000D03*
X60000000Y-52000000D03*
X62540000Y-52000000D03*
X65080000Y-52000000D03*
G04 #@! TD*
D12*
G04 #@! TO.C,CN1*
X64000000Y-41951750D03*
X60000000Y-38051750D03*
X56000000Y-41151750D03*
G04 #@! TD*
D13*
G04 #@! TO.C,R8*
X64400000Y-46100000D03*
X62400000Y-46100000D03*
G04 #@! TD*
G04 #@! TO.C,R6*
X57600000Y-46100000D03*
X55600000Y-46100000D03*
G04 #@! TD*
M02*
